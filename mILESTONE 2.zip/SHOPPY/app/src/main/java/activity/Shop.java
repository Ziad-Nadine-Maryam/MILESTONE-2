package activity;

public class Shop {
    public int id;
    public String name;
    public double price;
    public double distance;
    public String pname;
    public String special;





    public Shop(){
        this.id=id;
        this.name=name;
        this.price=price;
        this.distance=distance;
        this.pname=pname;
        this.special=special;
    }



}
