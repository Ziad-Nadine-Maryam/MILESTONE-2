
package activity;
        import android.Manifest;
        import android.app.ProgressDialog;
        import android.content.Context;
        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.graphics.Typeface;
        import android.graphics.drawable.Drawable;
        import android.location.Location;
        import android.os.AsyncTask;
        import android.os.Bundle;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.core.app.ActivityCompat;
        import androidx.core.content.res.ResourcesCompat;
        import androidx.recyclerview.widget.GridLayoutManager;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import app.AppConfig;
        import app.AppController;
        import helper.SQLiteHandler;
        import helper.SessionManager;


        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.ImageView;
        import android.widget.ListView;
        import android.widget.ProgressBar;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;

        import com.android.volley.Request;
        import com.android.volley.RequestQueue;
        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.StringRequest;
        import com.android.volley.toolbox.Volley;
        import com.example.shoppy.R;
        import com.google.android.gms.location.FusedLocationProviderClient;
        import com.google.android.gms.location.LocationServices;
        import com.google.android.gms.maps.SupportMapFragment;
        import com.google.android.gms.maps.model.LatLng;
        import com.google.android.gms.tasks.OnSuccessListener;
        import com.google.android.gms.tasks.Task;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;
        import activity.ListActivity.*;


public class List2Activity extends AppCompatActivity {
    ListView SubjectListView;
    ProgressBar progressBarSubject;
    private ProgressDialog pDialog;
    private SessionManager session;
    private SQLiteHandler db;
    private Shop shop;
    static Location currentLocation;
    static double lat;
    static double lgt;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    public ArrayList<Shop> shopList = new ArrayList<Shop>();
    public ArrayList<Shop> shopAttributes = new ArrayList<Shop>();
    String productName=ListActivity.productName;
    //public ArrayList<Shop> finalList = new ArrayList<Shop>();
    String s;
    String ServerURL = "http://192.168.43.29/android_login_api/shopfetch.php";
    String Server = "http://192.168.43.29/android_login_api/distancefetch.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list2);
        // final ListView list = findViewById(R.id.listview);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLocation();


        SubjectListView = (ListView) findViewById(R.id.listview1);
        System.out.println("Check Product"+productName);







       String tag_string_req = "req_login";
         StringRequest strReq = new StringRequest(Request.Method.POST,
                ServerURL, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) { ///shop_products table
                //shop=new Shop();


                try {

                    JSONArray x = new JSONArray(response);
                    JSONObject jObj;


                    for (int i = 0; i < x.length(); i++) {
                        jObj = x.getJSONObject(i);
                        shop=new Shop();
                        shop.pname=jObj.getString("product_name");
                        if(shop.pname.equals(productName)) {
                            // shop.id= Integer.parseInt(jObj.getString("id"));
                            shop.name = jObj.getString("shop_name");

                            shop.price = Double.parseDouble(jObj.getString("price"));
                            shop.special = jObj.getString("special offers available");
                            //shop distance???
                            System.out.println("Print id " + shop.id);
                            System.out.println("Print Name " + shop.name);
                            System.out.println("Print price " + shop.price);
                            System.out.println("Print offer " + shop.special);

                            shopList.add(shop);
                        }

                        }


                    System.out.println("List size is "+shopList.size());
                    //NewAdapter adapter = new NewAdapter(shopList, getApplicationContext());
                   // SubjectListView.setAdapter(adapter);


                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    System.out.println("Catch1");
                    Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("catch2");
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                //hideDialog();
            }

        });
        StringRequest str = new StringRequest(Request.Method.POST,
                Server, new Response.Listener<String>() {
            @Override ///// shop table
            public void onResponse(String response) {
                System.out.println("Here!");


                try {

                    JSONArray y = new JSONArray(response);
                    JSONObject jObj;

                    for(int k=0;k<shopList.size();k++) {
                        String name=shopList.get(k).name;
                        System.out.println("alllllllllllllllllllllllllllllllllllllllllllaaaaaaaaaaaaaaahhhhhhhhhhhhhhhhhh");
                        for (int j = 0; j < y.length(); j++) {
                            System.out.println("Henaaaasssssssssssssssssssssssssssssssssssssssssssssss");
                            if (y.getJSONObject(j).getString("name").equals(name)) {
                                System.out.println("Henaaaa");
                                Shop myShop = new Shop();
                                jObj = y.getJSONObject(j);
                                myShop.name = jObj.getString("name");
                                myShop.special = shopList.get(k).special;
                                myShop.price = shopList.get(k).price;
                                Location A = new Location("shop");
                                A.setLatitude(jObj.getDouble("latitude"));
                                A.setLongitude(jObj.getDouble("longitude"));
                                System.out.println(A.getLongitude());
                                System.out.println(A.getLatitude());
                                Location B = new Location("client");
                                B.setLongitude(lgt);
                                B.setLatitude(lat);


                              // B.setLongitude(currentLocation.getLongitude());
                               //B.setLatitude(currentLocation.getLatitude());
                                double distance = A.distanceTo(B);
                                System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz" + distance);
                                myShop.distance = distance;
                                shopAttributes.add(myShop);
                            }
                        }
                    }
                    System.out.println("List size is "+shopAttributes.size());
                    //System.out.println(("Awel shop "+ shopAttributes.get(0).name));
                    NewAdapter adapter = new NewAdapter(shopAttributes, getApplicationContext());
                    SubjectListView.setAdapter(adapter);





                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    System.out.println("Catch1");
                    Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("catch2");
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                //hideDialog();
            }

        });





        AppController.getInstance().addToRequestQueue(str, tag_string_req);
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);





    }

    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    lat=currentLocation.getLatitude();
                    lgt=currentLocation.getLongitude();
                    System.out.println("kkkkkkkkkkjjhh"+currentLocation.getLongitude());
                    //Toast.makeText(getApplicationContext(), currentLocation.getLatitude() + "" + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }


    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }



}



