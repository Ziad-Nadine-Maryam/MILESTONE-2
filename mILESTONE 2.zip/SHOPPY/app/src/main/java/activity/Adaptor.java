package activity;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.shoppy.R;

import java.util.ArrayList;

public class Adaptor extends RecyclerView.Adapter<Adaptor.ProgramingViewHolder> {
    private ArrayList<product> data;
    OnShopItemClicked onShopItem;
    public interface OnShopItemClicked{
        void onShopItem(int position);
        }




    public Adaptor(ArrayList<product> data,OnShopItemClicked onShopItem){
        this.data=data;
        this.onShopItem=onShopItem ;
    }
    public static class ProgramingViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView TextView1 ;
        OnShopItemClicked onShopItemClicked ;



        public ProgramingViewHolder(View itemView , OnShopItemClicked onShopItemClicked) {
            super(itemView) ;
            TextView1 = itemView.findViewById(R.id.textView3) ;
            this.onShopItemClicked = onShopItemClicked ;
            itemView.setOnClickListener(this) ;
        }


        @Override
        public void onClick(View v) {
            onShopItemClicked.onShopItem(getAdapterPosition());

        }
    }

    @NonNull
    @Override
    public ProgramingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rlist, parent,false);
        ProgramingViewHolder evh = new ProgramingViewHolder(v , onShopItem) ;
        return evh ;
    }


    @Override
    public void  onBindViewHolder(@NonNull ProgramingViewHolder holder, int position) {
        product currentItem = data.get(position) ;
        holder.TextView1.setText(currentItem.getName());
       // holder.TextView2.setText(String.valueOf(currentItem.getPrice()));
        //holder.TextView3.setText(String.valueOf(currentItem.getDistance()));

    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}